database =  {
    host: 'bbgxsoau4hkg7rc4zhy8-mysql.services.clever-cloud.com',
    user: 'uwecu8xyfuk1bsmu',
    password: 'W8b5ZtucCC2udsiktpX9',
    database: 'bbgxsoau4hkg7rc4zhy8'


};

module.exports = database;